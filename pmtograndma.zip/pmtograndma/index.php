<?php
require("timezone.php");
$utc = date_default_timezone_get();
$utc2 = date_default_timezone_get();


    $ip_v2= get_client_ip();
    $ipInfo = file_get_contents('http://ip-api.com/json/' . $ip_v2);
    $ipInfo = json_decode($ipInfo);
    $timezone = $ipInfo->timezone;
    date_default_timezone_set($timezone);
    $user_date = date('d M Y');
    $user_time = date('H:i:s');
    $script_tz = date_default_timezone_get();
    $dt = new DateTime($utc);
    $tz = new DateTimeZone('Africa/Lagos');
    $dt->setTimezone($tz);
    $our_time_zone=1;
    $new_date = $dt->format('d-m-y');
    $server_time = $dt->format('H:i:s');
    $difernt = ($server_time - $user_time )."<br />";
    $user_time_zone=($our_time_zone - $difernt);
    $time_to_add=($our_time_zone - $user_time_zone);
    

// $datetime = new DateTime($new_date.'T03:30', new DateTimeZone('Africa/Lagos'));
// $datetime->setTimezone(new DateTimeZone($script_tz));

function tzconverter($rtime){
    
    $datetime = new DateTime('2020-01-21T'.$rtime, new DateTimeZone('Africa/Lagos'));
    $datetime->setTimezone(new DateTimeZone($GLOBALS['script_tz']));
    print $datetime->format('h:iA ')." ";
}
function offset(){
    $datetime = new DateTime('2020-01-21T'.$rtime, new DateTimeZone('Africa/Lagos'));
    $datetime->setTimezone(new DateTimeZone($GLOBALS['script_tz']));
    echo $datetime->format('P)')." ";
}

?>

<!DOCTYPE html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-83166458-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-83166458-1');
</script>

    <title>The Explain-PM-To-Grandma Collaborative Training To DIGEST Knowledge, BLOW UP Managerial Capacity & BLAST the PMP Exam </title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="V24/v24_style.css" />
  <link rel="stylesheet"  href="V24/basictable.css" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script type="text/javascript" src="V24_Basic/jquery.basictable.min.js"></script>
    
<script type="text/javascript">
    /** This section is only needed once per page if manually copying **/
    if (typeof MauticSDKLoaded == 'undefined') {
        var MauticSDKLoaded = true;
        var head            = document.getElementsByTagName('head')[0];
        var script          = document.createElement('script');
        script.type         = 'text/javascript';
        script.src          = 'http://gem4success.com/connect/media/js/mautic-form.js';
        script.onload       = function() {
            MauticSDK.onLoad();
        };
        head.appendChild(script);
        var MauticDomain = 'http://gem4success.com/connect';
        var MauticLang   = {
            'submittingMessage': "Please wait..."
        }
    }
</script>



  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
      
      <div class="container-fluid">
        <div class="d-flex align-items-center">
<!--           <div class="site-logo mr-auto w-25"><a href="index.html">OneSchool</a></div> -->

          <div class="mx-auto text-center">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none d-lg-block  m-0 p-0">
<!--                 <li><a href="#home-section" class="nav-link">Home</a></li>
                <li><a href="#courses-section" class="nav-link">Courses</a></li>
                <li><a href="#programs-section" class="nav-link">Programs</a></li>
                <li><a href="#teachers-section" class="nav-link">Teachers</a></li> -->

                <li><a href="#" class="nav-link">Home</a></li>
                <li><a href="#package" class="nav-link">Training Package</a></li>
                <li><a href="#upcoming" class="nav-link">Upcoming Sessions</a></li>
                <li><a href="#register" class="nav-link">Register</a></li>
                <li><a href="#faq" class="nav-link">FAQ</a></li>
              </ul>
            </nav>
          </div>

<!--           <div class="ml-auto w-25">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu site-menu-dark js-clone-nav mr-auto d-none d-lg-block m-0 p-0">
                <li class="cta"><a href="#contact-section" class="nav-link"><span>Contact Us</span></a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black float-right"><span class="icon-menu h3"></span></a>
          </div> -->
        </div>
      </div>
      
    </header>

    <div class="intro-section" id="home-section">
      
      <div class="slide-1" style="background-image: url('images/hero_1.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12 tadjust"  style="text-align:center;">
              <p  style="text-align:center;">I want to <span style="padding:5px; background-color:#d00; color:#fff;">PERSONALLY</span> coach a limited number of people to PMP exam success.</p>

                <h1 class="section-title">The Explain-PM-To-Grandma Collaborative Training To DIGEST Knowledge, BLOW UP Managerial Capacity & BLAST the PMP Exam</h1>
                
                <style>
                  .embed-container { position: relative; padding-bottom: 49%; height: 0; overflow: hidden; max-width: 100%; } 
                  .embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
                </style>
                <div class='embed-container'><iframe src='https://www.youtube.com/embed/5xZohZFLGXs' frameborder='0' allowfullscreen></iframe></div>
                <p data-aos="fade-up" data-aos-delay="50"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill" style="margin-top:5px;">Yes, Coach Me to success! </a></p>
              </div>  

<!--             <div class="col-12">
              <div class="row align-items-center"> -->
<!--                 <div class="col-lg-6 mb-4">
                  <h1  data-aos="fade-up" data-aos-delay="100">Learn From The Expert</h1>
                </div> -->

<!--                 <div class="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="500">
                  <form action="" method="post" class="form-box">
                    <h3 class="h4 text-black mb-4">Sign Up for FREE</h3>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Email Addresss">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control" placeholder="Password">
                    </div>
                    <div class="form-group mb-4">
                      <input type="password" class="form-control" placeholder="Re-type Password">
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary btn-pill" value="Sign up">
                    </div>
                  </form>

                </div> -->
<!--               </div>
            </div> -->
            
          </div>
        </div>
      </div>
    </div>

    <div class="site-section" id="programs-section">
      <div class="container">
        <div class="row mb-5 align-items-center">
          <div class="col-lg-4 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/hybee10x_.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-7 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">I am Oladeji Oluwaseyi Hybee10x</h2>
            <p class="mb-4">I am a seasoned project manager and IT Consultant with vast experience in project management and IT across private and public sector. I hold numerous IT and management certifications including MBA, M.Inf.Sci, PMP, CISA & COBIT5. <br><br><i>I am a high performance coach, with a deep passion for helping people reach their full potential</i></u><br><a href="https://www.linkedin.com/in/iboladeji/">https://www.linkedin.com/in/iboladeji/</a></p>

          </div>
        </div>


        <div class="row mb-7 justify-content-center">
          <div class="col-lg-11 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">The time is NOW!</h2>
            <p>
              
                <h3>The PMP syllabus change deadline is approaching. Avoid the maad rush</h3>
              <ul>
                <li>Join this limited group of people I want to personally coach to success.</li>
                <li>I need fresh testimonials; I need your testimonial and I am rolling up sleeves for this!</li>
                <li>Passing the PMP exam is tough, but not rocket science. Together, we can get there</li>
              </ul>
          </div>

          <div class="col-lg-11 text-center"  data-aos="fade-up" data-aos-delay="" style="background-color:#eee; ">
              <h2 class="section-title" style="padding:10px;color:orange;">ANY OF THESE SOUND FAMILIAR?</h2>
                <div class="familiar" style="padding:0 100px; text-align:left;">
                  🤯 I want to be a better leader, coordinator, facilitator<br>
                  😩 I want to grow my career and need to up my management skills<br>
                  😥 My business needs more attention and I really need to organize things better<br>
                  🤯 I am interested in improving my critical thinking skills<br>
                  😰 Are you interested in cutting cost from failed projects and related initiatives<br>
                  👮 I want to become a GENERAL in management of limited resources<br>
                  <h4> 🧟‍♂️I want to learn but tough to fit into conventional training schedules</h4>
                </div>    
              <p data-aos="fade-up" data-aos-delay="100"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">YES, COACH ME TO SUCCESS</a></p>
          </div>
        </div>

        <div class="row mb-5 justify-content-center">
          <div class="col-lg-11 mb-5 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title" id="package" style="padding-top:20px;">TRAINING PACKAGE</h2>
            <p class="mb-7">
              <ul>
                <li>ZOOM webinar for collaborative daily sessions</li>
                <li>LIVE audio streaming of sessions for those with weak internet speed or those in transit</li>
                <li>Closed Whatsapp group for deeper engagement, mentoring and inter-student learning</li>
              </ul>
              </p>
          </div>
        </div>
 
        <div class="row">

          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="teacher text-center">
              <img src="images/step1.jpg" alt="Image" class="img-fluid w-50 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">ZOOM webinar class with flexible timing for 3-4 weeks</h3>
                <p class="position">Choose an appropriate timing from the options below </p>
                <p><span style="color:#d00;">To have a feel of how the class would look like</span>, <a href="https://youtu.be/I2yPAOANMgk">click here to watch a recording of one of past sessions</a></p>
                <!-- <p><strong><span style="color:#d00;">Time</span></strong>: 8:30pm - 10:00pm (we call this POWER HOUR  💪)<br><strong><span style="color:#d00;">Upcoming Batches</span></strong><br> Nov. 25th - Dec. 8th, 2019 <br> Dec. 27th, 2019 - Jan. 10th, 2020 </p> -->
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div class="teacher text-center">
              <img src="images/step2.jpg" alt="Image" class="img-fluid w-50 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">4 weeks of turbo-mode GUIDED-STUDY</h3>
                <p class="position">We are holding your hand all the way</p>
                <p>We are giving you <u>INTENSE MENTORSHIP</u> and useful study materials for the guided-study(slides,flash cards, over 2000 practice questions, 8 mock exams etc)</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="300">
            <div class="teacher text-center">
              <img src="images/step3.jpg" alt="Image" class="img-fluid w-50 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">Shatter the PMP Exam!</h3>
                <p class="position">We help with PMP Exam Registration</p>
                <p>The complex procedures could be intimidating. We have your back on this.</p>
              </div>
            </div>
          </div>
        </div>


    <div class="site-section pb-0" id="upcoming">
      <div class="future-blobs">
<!--         <div class="blob_2">
          <img src="images/blob_2.svg" alt="Image">
        </div> -->
        <div class="blob_1">
          <img src="images/blob_1.svg" alt="Image">
        </div>
      </div>
  </div>
      <div class="container">
        <div class="row mb-5 justify-content-center" data-aos="fade-up" data-aos-delay="">
          <div class="col-lg-7 text-center">
            <h2 class="section-title">UPCOMING CLASSES</h2>
                        <p class="mb-7">
                          <h3>Join our high-impact sessions :💪</h3>
              </p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 ml-auto align-self-start text-center"  data-aos="fade-up" data-aos-delay="100">

            <div>
            <body>
            <div id="page">
                <div id="times_name"><div id="zone">Your Time Zone: </div><select id="sel"><option><?php echo '(GMT'?><?php offset()?><?php echo $script_tz?></option></select></div>
              <table id="table">
                <thead>
                    <tr>
                      <th class="cent">Class Start Date</th>
                      <th class="cent">Class Schedule</th>
                      <th class="cent">Class Time</th>
                      <th class="cent">Your Local Class Time</th>
                      <th class="cent"> Class Price</th>
                      <th class="cent" style="font-size:20px">👉</th> 
                    </tr>
                </thead>
                <tbody>
                    <tr>
                      <td class="cent">Saturday, February 01,2020</td>
                      <td class="cent">Sat & Sun</td>
                      <td class="cent">4 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('03:30')?>  to  <?php tzconverter('06:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr>
                      <td class="cent">Sunday, February 02,2020</td>
                      <td class="cent">Daily</td>
                      <td class="cent">3 Weeks<br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('17:00')?> to <?php tzconverter('18:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      </td>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr>
                      <td class="cent">Monday, February 03,2020</td>
                      <td class="cent">Mon & Wed</td>
                      <td class="cent">4 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('03:30')?> to <?php tzconverter('06:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    
            <!--this is for March class   -->
                     <tr class="table-two-axis" style="display: none">
                      <td class="cent">Sunday, March 01,2020</td>
                      <td class="cent">Daily</td>
                      <td class="cent">3 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('17:00')?>  to  <?php tzconverter('18:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr class="table-two-axis" style="display: none">
                      <td class="cent">Sunday, March 01,2020</td>
                      <td class="cent">Daily</td>
                      <td class="cent">3 Weeks<br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('20:30')?> to <?php tzconverter('22:00'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr class="table-two-axis" style="display: none">
                      <td class="cent">Monday, March 02,2020</td>
                      <td class="cent">Mon & Wed</td>
                      <td class="cent">4 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('20:30')?> to <?php tzconverter('23:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr class="table-two-axis" style="display: none">
                      <td class="cent">Saturday, March 07,2020</td>
                      <td class="cent">Sat & Wed</td>
                      <td class="cent">4 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('20:30')?> to <?php tzconverter('23:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
            <!--this is for April class-->
                    <tr class="table-three-axis" style="display: none">
                      <td class="cent">Saturday, April 04,2020</td>
                      <td class="cent">Sat & Wed</td>
                      <td class="cent">4 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('20:30')?> to <?php tzconverter('23:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr class="table-three-axis" style="display: none">
                      <td class="cent">Sunday, April 05,2020</td>
                      <td class="cent">Daily</td>
                      <td class="cent">3 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('17:00')?>  to  <?php tzconverter('18:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr class="table-three-axis" style="display: none">
                      <td class="cent">Sunday, April 05,2020</td>
                      <td class="cent">Daily</td>
                      <td class="cent">3 Weeks<br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('20:30')?> to <?php tzconverter('22:00'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    <tr class="table-three-axis" style="display: none">
                      <td class="cent">Monday, April 06,2020</td>
                      <td class="cent">Mon & Wed</td>
                      <td class="cent">4 Weeks <br/><font size="2" color="red">+5 weeks of intense coaching</font></td>
                      <td class="cent"><?php tzconverter('20:30')?> to <?php tzconverter('23:30'); ?><br/><?php echo ' (GMT'?><?php offset()?><?php echo $script_tz ?></td>
                      <td class="cent"><div><span class="tags"><span class="price-tag"><a href="javascript:void()"><s class="cancelled">$750</s>  $550</a></span></span></div>
                      <td class="cent"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">REGISTER</a></td>
                    </tr>
                    
                  </tbody>
  </table>
<button class="read_more">load More Sessions</button>
  </body>
<script>
 var count=0;
$(document).ready(function(){
    
  $(".read_more").click(function(){
      if (count===0){
          $(".table-two-axis").toggle( "slow" );
          count+=1;
      }
      else{
       $(".table-three-axis").toggle( "slow" ); 
       count-=1;
      }
  });
});
</script>
 <script type="text/javascript">
    $(document).ready(function() {
      $('#table').basictable();

      $('#table-breakpoint').basictable({
        breakpoint: 768
      });

      $('#table-container-breakpoint').basictable({
        containerBreakpoint: 485
      });

      $('#table-swap-axis').basictable({
        swapAxis: true
      });

      $('#table-force-off').basictable({
        forceResponsive: false
      });

      $('#table-no-resize').basictable({
        noResize: true
      });

      $('#table-two-axis').basictable();

      $('#table-max-height').basictable({
        tableWrapper: true
      });
    });
  </script>
  <style>
      #tabuo{
          display:none;
      }
      .price{
          background-color: red;
          border-radius: 5px 5px 5px 5px;
          color: white;
          padding: 4px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
          margin: 4px 2px;
      }
      .cent{
          text-align:center;
      }
      .cancelled{
          color:black;
      }
      .read_more{
          background-color: #008CBA;
          border-radius: 5px 5px 5px 5px;
          color: white;
          padding: 4px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
          margin: 4px 2px;
          cursor: pointer;
      }
      #times_name{
          display:flex;
          margin-left:5%;
          flex-wrap:wrap;
      }
       #sel{
           border-radius:5px 5px 5px 5px;
           max-width: 80%;
           margin-left:2%;
           height:3%;
      }
      @media only screen and (max-width: 300px){
          #sel{
             font-size: 15px;
             margin-top:5%;
          }
          #zone{
              font-size: 15px;
          }
          .cent{
          text-align:center;
      }
      }
      
  </style>
    </div>

</div>
</div>
</div>
    
        <div class="row mb-5 justify-content-center">
          <div class="col-lg-9 mb-5 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title" id="instructor" style="padding-top:20px;">THAT IS NOT ALL 😧</h2>
          </div>
        </div> 

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/undraw_youtube_tutorial.svg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">You get our 15hr online PMP course</h2>
            <p class="mb-4">We are giving you access to our 15hour online PMP certification course. Learn anywhere and <u>make up material if you miss and LIVE daily session</u></p>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">15 hours of multimedia lessons</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">Watch anywhere and anytime</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0"><a href="http://alearnko.com/courses/15hr-online-pmp-course/">Click here to view the course</a></h3></div>
            </div>            

            <br>
            <p data-aos="fade-up" data-aos-delay="100"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">YES, COACH ME TO SUCCESS</a></p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5 order-1 order-lg-2" data-aos="fade-up" data-aos-delay="100">
            <img src="images/headphone.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 mr-auto order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">Daily 20-30mins downloadable audio notes</h2>
            <p class="mb-4">We would be sending you 20-30mins downloadable audio notes every morning to <u>learn/revise while you work, walk & drive</u>. </p>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">overview of learnt materials</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">case studies, Q & As and more!</h3></div>
            </div>

            <br>
            <p data-aos="fade-up" data-aos-delay="100"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">YES, COACH ME TO SUCCESS</a></p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/undraw_teaching.svg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4" id="date">Intense Mentorship</h2>
            <p class="mb-4">We are not throwing these at you, we set study targets and <u>followup with periodic calls</u> </p>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">Check on you to ensure understanding</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">Check on you for Q&A</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">Check on you for accountability</h3></div>
            </div>
            <br>
            <p data-aos="fade-up" data-aos-delay="100"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">YES, COACH ME TO SUCCESS</a></p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-5 mb-5 order-1 order-lg-2" data-aos="fade-up" data-aos-delay="100">
            <img src="images/you.png" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-5 mr-auto order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">Better You, v2.0!</h2>
            <p class="mb-4"><span style="color:red;">We give you access to tons of templates to aid your practical application.</span> <br>Outside of the "book", we would be discussing how Project Management can <u>enhance your life/career and give you a competitive edge</u></p>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">become more organized</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">improve your critical thinking skills</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">become a better manager, facilitator and more!</h3></div>
            </div>
            <br>
            <p data-aos="fade-up" data-aos-delay="100"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">YES, COACH ME TO SUCCESS</a></p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-5 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/certificate.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4" id="date">Certificate of Completion</h2>
            <p class="mb-4">Once you complete this course, you will receive a 'Certificate of Completion' that you can use towards your 35 Contact Hours. </u> </p>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">Add it to your Resume/CV to exhibit your knowledge and stand out</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">Add to LinkedIn Profile under the achievements section.</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">35 Contact Hour certificate to qualify you for the PMP exam</h3></div>
            </div>
            <br>
            <p data-aos="fade-up" data-aos-delay="100"><a href="#register" class="btn btn-primary py-3 px-5 btn-pill">YES, COACH ME TO SUCCESS</a></p>
          </div>
        </div>
        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 mb-5 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title" id="instructor">AND MORE!</h2>
            <p class="mb-5">Get access to detailed materials from some of our past courses/seminars</p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/more1_new.png" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">Negotiation</h2>
            <p class="mb-4">An Essential Tool for Successful Project Stakeholder Management</u></p>

<!--             <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">15 hours of multimedia lessons</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">Watch anywhere and anytime</h3></div>
            </div> -->

          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-5 mb-5 order-1 order-lg-2" data-aos="fade-up" data-aos-delay="100">
            <img src="images/more2.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-7 mr-auto order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">Essentials of Team Building</h2>
            <p class="mb-4">Understanding the Team Development Process</u>. </p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/more3_new.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4" id="date">Improving Your Decision Making Skills</h2>
            <p class="mb-4">Join the smart people who use Decision Tree Analysis to improve their business and personal decicion making process</u> </p>


          </div>
        </div>

      </div>
    </div>

    <div class="site-section bg-image overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-8 text-center testimony">
            <img src="images/silohet.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
            <h3 class="mb-4">Mrs Habeebat (NNPC)</h3>
            <blockquote>
              <p id="register">&ldquo; I had attended several PMP prep courses but after yours I had the courage to attempt it and I passed &rdquo;</p>
            </blockquote>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section" id="teachers-section">
      <div class="container">

        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 mb-5 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2  class="section-title" id="instructor">IT IS A STEAL 🤩</h2>
            <p class="mb-5"><span style="color:#d00;">Get maximum value at a tiny fraction of its worth</span></p>
          

            <table>
              <tr> <td>The intense mentorship</td><td>✔️💯</td></tr>
              <tr> <td>The convenience of piecemeal daily classes</td><td>✔️💯</td></tr>
              <tr> <td>The 15hr video online course</td><td>✔️💯</td></tr>
              <tr> <td>The daily downloadable audios</td><td>✔️💯</td></tr>
              <tr> <td>High value materials for guided-study</td><td>✔️💯</td></tr>
              <tr> <td>Tons and tons of practice questions</td><td>✔️💯</td></tr>
              <tr> <td>The support from community of others taking the exam</td><td>✔️💯</td></tr>

            </table>
              
              <h3>You ordinarily would not pay less than <u>$1,500</u> for this package</h3><br>
              <s>$1,200</s> <br>
              <s>$1000</s> <br>
              <s>$750</s> <br>
              <h4>You are paying a heavily discounted price of $550</h4>
              <span style="color:#d00;">Registration closes soon, few spaces left.</span>
            
          </div>

          <div class="row mb-5 align-items-center justify-content-center">
            <div class="col-lg-5 mb-5" data-aos="fade-up" data-aos-delay="100" style="background-color:#eee;">
                  <h2 class="section-title" style="padding:10px;color:orange;">To Register</h2><br/>
                  <div class="familiar">
                    <span> Kindly fill the form below or contact us via: <ul><li>Call/SMS - +1(972) 994 6898</li><li>Email - info@pmtograndma.com</li></ul></span>
                  </div>   
            </div>
            <div class="col-lg-5 mb-5" data-aos="fade-up" data-aos-delay="100" style="background-color:#eee; margin-left:20px;">
                <h2 class="section-title" style="padding:10px;color:orange;">To Pay</h2>
                  <div class="familiar">
                    <p>Online Payment: <a href="https://paystack.com/pay/gem">https://paystack.com/pay/gem</a></p>
                    <p>Bank Transfer
                      <ul>
                        <li>GTB/Edawah/0030212250</li>
                        <li>Stanbic/Edawah/0011002005</li>
                      </ul>
                    </p>
                  </div>   
            </div>
        </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-4 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/guarantee.png" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-7 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">100% Pass Guarantee</h2>
            <p class="mb-4">We are confident you are going to learn everything you need to know to pass your PMP. If you do not pass your PMP within 6 weeks after registration, simply send your test scores to us and we will give you a full refund.</u></p>

            <div class="d-flex align-items-center custom-icon-wrap mb-3">
              <span class="custom-icon-inner mr-3"><span class="icon icon-graduation-cap"></span></span>
              <div><h3 class="m-0">Also, we would offer a FULL REFUND if you are not convinced after 3 sessions</h3></div>
            </div>

            <div class="d-flex align-items-center custom-icon-wrap">
              <span class="custom-icon-inner mr-3"><span class="icon icon-university"></span></span>
              <div><h3 class="m-0">All the risk is on us, as it should be. You literally have nothing to lose.</h3></div>
            </div>

          </div>
        </div>

      </div>
    </div>

    <div class="site-section pb-0">

      <div class="future-blobs">
        <div class="blob_2">
          <img src="images/blob_2.svg" alt="Image">
        </div>
        <div class="blob_1">
          <img src="images/blob_1.svg" alt="Image">
        </div>
      </div>
      <div class="container">
        <div class="row mb-5 justify-content-center" data-aos="fade-up" data-aos-delay="">
          <div class="col-lg-7 text-center">
            <h2 class="section-title">Register Here</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 ml-auto align-self-start"  data-aos="fade-up" data-aos-delay="100">

            <div class="p-4 rounded bg-white why-choose-us-box">

                <style type="text/css" scoped>
                    .mauticform_wrapper { max-width: 600px; margin: 10px auto; }
                    .mauticform-innerform {}
                    .mauticform-post-success {}
                    .mauticform-name { font-weight: bold; font-size: 1.5em; margin-bottom: 3px; }
                    .mauticform-description { margin-top: 2px; margin-bottom: 10px; }
                    .mauticform-error { margin-bottom: 10px; color: red; }
                    .mauticform-message { margin-bottom: 10px;color: green; }
                    .mauticform-row { display: block; margin-bottom: 20px; }
                    .mauticform-label { font-size: 1.1em; display: block; font-weight: bold; margin-bottom: 5px; }
                    .mauticform-row.mauticform-required .mauticform-label:after { color: #e32; content: " *"; display: inline; }
                    .mauticform-helpmessage { display: block; font-size: 0.9em; margin-bottom: 3px; }
                    .mauticform-errormsg { display: block; color: red; margin-top: 2px; }
                    .mauticform-selectbox, .mauticform-input, .mauticform-textarea { width: 100%; padding: 0.5em 0.5em; border: 1px solid #CCC; background: #fff; box-shadow: 0px 0px 0px #fff inset; border-radius: 4px; box-sizing: border-box; }
                    .mauticform-checkboxgrp-row {}
                    .mauticform-checkboxgrp-label { font-weight: normal; }
                    .mauticform-checkboxgrp-checkbox {}
                    .mauticform-radiogrp-row {}
                    .mauticform-radiogrp-label { font-weight: normal; }
                    .mauticform-radiogrp-radio {}
                    .mauticform-button-wrapper .mauticform-button.btn-default, .mauticform-pagebreak-wrapper .mauticform-pagebreak.btn-default { color: #5d6c7c;background-color: #ffffff;border-color: #dddddd;}
                    .mauticform-button-wrapper .mauticform-button, .mauticform-pagebreak-wrapper .mauticform-pagebreak { display: inline-block;margin-bottom: 0;font-weight: 600;text-align: center;vertical-align: middle;cursor: pointer;background-image: none;border: 1px solid transparent;white-space: nowrap;padding: 6px 12px;font-size: 13px;line-height: 1.3856;border-radius: 3px;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;}
                    .mauticform-button-wrapper .mauticform-button.btn-default[disabled], .mauticform-pagebreak-wrapper .mauticform-pagebreak.btn-default[disabled] { background-color: #ffffff; border-color: #dddddd; opacity: 0.75; cursor: not-allowed; }
                    .mauticform-pagebreak-wrapper .mauticform-button-wrapper {  display: inline; }
                </style>
                <div id="mauticform_wrapper_pmwebinar" class="mauticform_wrapper">
                    <form autocomplete="false" role="form" method="post" action="http://gem4success.com/connect/form/submit?formId=4" id="mauticform_pmwebinar" data-mautic-form="pmwebinar" enctype="multipart/form-data">
                        <div class="mauticform-error" id="mauticform_pmwebinar_error"></div>
                        <div class="mauticform-message" id="mauticform_pmwebinar_message"></div>
                        <div class="mauticform-innerform">

                            
                          <div class="mauticform-page-wrapper mauticform-page-1" data-mautic-form-page="1">

                            <div id="mauticform_pmwebinar_full_name" data-validate="full_name" data-validation-type="text" class="mauticform-row mauticform-text mauticform-field-1 mauticform-required">
                                <label id="mauticform_label_pmwebinar_full_name" for="mauticform_input_pmwebinar_full_name" class="mauticform-label">Full name</label>
                                <input id="mauticform_input_pmwebinar_full_name" name="mauticform[full_name]" value="" class="mauticform-input" type="text">
                                <span class="mauticform-errormsg" style="display: none;">This is required.</span>
                            </div>

                            <div id="mauticform_pmwebinar_whatsapp_phone_number" data-validate="whatsapp_phone_number" data-validation-type="tel" class="mauticform-row mauticform-tel mauticform-field-2 mauticform-required">
                                <label id="mauticform_label_pmwebinar_whatsapp_phone_number" for="mauticform_input_pmwebinar_whatsapp_phone_number" class="mauticform-label">Phone Number</label>
                                <input id="mauticform_input_pmwebinar_whatsapp_phone_number" name="mauticform[whatsapp_phone_number]" value="+23480" class="mauticform-input" type="tel">
                                <span class="mauticform-errormsg" style="display: none;">This is required.</span>
                            </div>

                            <div id="mauticform_pmwebinar_discount_coupon" class="mauticform-row mauticform-text mauticform-field-3">
                                <label id="mauticform_label_pmwebinar_discount_coupon" for="mauticform_input_pmwebinar_discount_coupon" class="mauticform-label">Discount coupon</label>
                                <span class="mauticform-helpmessage">...if applicable</span>
                                <input id="mauticform_input_pmwebinar_discount_coupon" name="mauticform[discount_coupon]" value="" class="mauticform-input" type="text">
                                <span class="mauticform-errormsg" style="display: none;"></span>
                            </div>

                            <div id="mauticform_pmwebinar_submit" class="mauticform-row mauticform-button-wrapper mauticform-field-4">
                                <button type="submit" name="mauticform[submit]" id="mauticform_input_pmwebinar_submit" value="" class="mauticform-button btn btn-default">Register me</button>
                            </div>
                            </div>
                        </div>

                        <input type="hidden" name="mauticform[formId]" id="mauticform_pmwebinar_id" value="4">
                        <input type="hidden" name="mauticform[return]" id="mauticform_pmwebinar_return" value="">
                        <input type="hidden" name="mauticform[formName]" id="mauticform_pmwebinar_name" value="pmwebinar">

                        </form>
                </div>



            </div>


          </div>
          <div class="col-lg-7 align-self-end"  data-aos="fade-left" data-aos-delay="200">
            <img src="images/person_transparent2.png" alt="Image" class="img-fluid">
          </div>
        </div>
      </div>
    </div>

    



     <div class="site-section bg-light" id="contact-section">
      <div class="container">

        <div class="row justify-content-center">
          <div class="col-md-9">


            
            <h2 class="section-title mb-9" id="faq">FAQ</h2>
            <p class="mb-5">For inquiries and more information, please contact me on 09099576339 (call/sms), Whatsapp <a href="https://wa.me/2349099576339">https://wa.me/2349099576339</a> or email on info@gem4success.com</p>
            <p><strong>1. I am not writing the PMP exam anytime soon, can I still partake?</strong><br>
            Sure, the massive knowledge and capacity enhancement is the main value!</p>

            <p><strong>2. What if I cannot make it to all the sessions?</strong><br>
            You have lots of value through the online video course you can follow at your pace and the daily audios sent to you</p>

            <p><strong>3. What if my internet connection fumbles suddenly and cannot follow the ZOOM webinar?</strong><br>
            We've got you covered. You can Listen LIVE through the alternative arrangement of audio streaming</p>

            <p><strong>4. What if I am not impressed after the first few classes?</strong><br>
            We refund you with no questions asked</p>

            <p><strong>5. Can I pay in installments?</strong><br>
            Yes</p>

            <p><strong>6. Is the time not too short?</strong><br>
            Not at all. With quality mentorship and materials, together with dedication from you, we would get there, God willing </p>

            <p><strong>7. Is group discount available</strong><br>
            Talk to us, we might be able to work out something</p>

            <p><strong>8. What do I get if I refer people?</strong><br>
            Talk to us, we might be able to work out commission for you</p>

            
            
          </div>
        </div>
      </div>
   </div>
    
     
    <footer class="footer-section bg-white">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <h3>About</h3>
            <p>GEM Center for Human Capital Development was established to address the ever increasing need for high quality knowledge for professionals and enthusiasts in general. </p>
          </div>

          <div class="col-md-3 ml-auto">
            <h3>Links</h3>
            <ul class="list-unstyled footer-links">
                <li><a href="#" class="nav-link">Home</a></li>
                <li><a href="#package" class="nav-link">Training Package</a></li>
                <li><a href="#upcoming" class="nav-link">Upcoming Sessions</a></li>
                <li><a href="#register" class="nav-link">Register</a></li>
                <li><a href="#faq" class="nav-link">FAQ</a></li>
            </ul>
          </div>

          <div class="col-md-4">
            <h3>Contact</h3>
            <p> GEM Building, KLM 2, Arulogun Road , Ojoo, Ibadan</p>
            <p>+23490 9957 6339 | info@gem4success.com</p>
<!--             <form action="#" class="footer-subscribe">
              <div class="d-flex mb-5">
                <input type="text" class="form-control rounded-0" placeholder="Email">
                <input type="submit" class="btn btn-primary rounded-0" value="Subscribe">
              </div>
            </form> -->
          </div>

        </div>

        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>

  
    
  </div> <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script>src="js/jquery.table-shrinker.js"</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="V24/jquery.basictable.min.js"></script>

  
  
  <script src="js/main.js"></script>
    
  </body>
</html>